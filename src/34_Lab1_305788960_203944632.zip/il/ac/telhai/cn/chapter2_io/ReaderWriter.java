package il.ac.telhai.cn.chapter2_io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class ReaderWriter {
	
	private static byte [] str;
	private static PipedOutputStream opipe;
	private static PipedInputStream ipipe;
	private static int pipe_size;
	static ArrayList<Integer> arr; 	
	public static void writeToFile(String fileName, String arg) throws IOException {
		try {
			File f = new File(fileName);
			
			if (f.canWrite()) {
				FileWriter fw = new FileWriter(f);
				fw.write(arg);     // todo - check if writes at the end of the current text
				fw.close();
			} else {
				System.out.println("can't write");
			}

		} catch (IOException e) {
			System.out.println("Wtf?");
			throw e;
		}
	}
	
	public static String getBytesDecimalFromFile(String fileName) throws IOException {
		File f = new File(fileName);
		if (! f.exists())
			throw new IOException("file not found");
		StringBuilder sb = new StringBuilder();
		if (! f.canRead()) {
			System.out.println("can't read");
		}
		Scanner s = new Scanner(f);
		String arg = new String();
		while (s.hasNextLine())
			arg = s.nextLine();
		byte ba [] = arg.getBytes(StandardCharsets.UTF_8);
		for (int i = 0 ; i < ba.length ; i++) {
			sb.append((256 + (int) ba[i]) % 256).append(',');
		}
		s.close();
		sb.deleteCharAt(sb.length() - 1);
		return sb.toString();
	}
	
	public static void writeToByteArray(String arg) throws IOException {
		str = arg.getBytes(StandardCharsets.UTF_8);
	}
	
	public static String getBytesDecimalFromByteArray() throws IOException {
		StringBuilder sb = new StringBuilder();
		for (int i = 0 ; i < str.length ; i++ ) {     // fr has chars to read
			sb.append((256 + (int) str[i]) % 256).append(',');
		}
		sb.deleteCharAt(sb.length() - 1);
		return sb.toString();
	}
	
	public static void writeToPipe(String arg) throws IOException {
		if (opipe == null || ipipe == null) {
			opipe = new PipedOutputStream();
			ipipe = new PipedInputStream();
			ipipe.connect(opipe);
			pipe_size = 0;
		}

		byte [] arr = arg.getBytes(StandardCharsets.UTF_8);
		for (int i = 0 ; i < arr.length ; i++) {
			opipe.write(arr[i]);
			opipe.flush();
			pipe_size++;
		}

	}
	
	public static String getBytesDecimalFromPipe() throws IOException {//		ipipe.available();
		StringBuilder sb = new StringBuilder();
		int num = - 1;
		for (int i = 0 ; i < pipe_size ; i++) {
			num = ipipe.read();
			sb.append((256 + num) % 256).append(',');
		}
		opipe.close();
		ipipe.close();
		sb.deleteCharAt(sb.length() - 1);
		return sb.toString();
	}
	
	public static void readIntoFile(String fileName) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Integer num;
		while ((num = Integer.parseInt(br.readLine())) >= 0) {
			if (num <= 1000)
				writeToFile(fileName, num.toString());
				arr.add(num); // Adds numbers to a global array
				
		}
	}
	
	public static void main(String [] args) throws NumberFormatException, IOException {
		arr = new ArrayList<>();
		for (int i = 0 ; i < args.length ; i++ ) {
			readIntoFile(args[i]);

		}
		Collections.sort(arr); // sort and print
		for (Integer num : arr) {
			System.out.println(num);
		}
		// todo - read the numbers from the files, sort them, and print them
	}
	
	
}
